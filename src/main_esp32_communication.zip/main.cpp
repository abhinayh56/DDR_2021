#include <Arduino.h>
#include "Filter.h"
#include "Math_functions.h"
#include "QuadEncoder.h"
#include "PID_controller.h"

// time variable starts ------------------------------------------------------------------------------------
float SampleFrequency = 500;
float dt = 1.0/SampleFrequency;
float loop_timer = 1000000.0*dt;
float t = 0;
// time variables ends -------------------------------------------------------------------------------------

// Robot parameters starts ---------------------------------------------------------------------------------
double L = 0.265; // wheel base in m
double r = 0.125/2.0; // wheel radius in m
unsigned long N_encoder = 133600.0;
// Robot parameters ends -----------------------------------------------------------------------------------

// Wheel odometry variables starts -------------------------------------------------------------------------
QuadEncoder enc_left(1, 2, 3);
QuadEncoder enc_right(2, 4, 5);
// encoder ticks
long count_L = 0;
long count_R = 0;

long count_L_pre = 0;
long count_R_pre = 0;

long N_L_pre = 0;
long N_R_pre = 0;

// wheel rpm
double w_L = 0;
double w_R = 0;

// center of mass velocity
double Vc = 0;
double Wc = 0;

// position, velocity, angle
double x   = 0;
double y   = 0;
double yaw_angle = 0;
double vx  = 0;
double vy  = 0;
double yaw_rate  = 0;

unsigned int odom_counter_50Hz = 1;
Filter_LP lpf_w_L;
Filter_LP lpf_w_R;
// Wheel odometry variables ends ---------------------------------------------------------------------------

// Controller variables starts -----------------------------------------------------------------------------
float Vc0 = 0; // m/sec
float Wc0 = 0; // deg/sec

float Vc0_max = 1.0; // m/sec
float Wc0_max = 8.2; // 470 deg/sec = 8.2 rad/sec
void validate_VWc0(float Vc0_=0, float Wc0_=0); // m/sec, rad/sec
float line_1(float v,float w);
float line_2(float v,float w);
float line_3(float v,float w);
float line_4(float v,float w);

int VWc_controller_counter50Hz = 1;

float rpm_L0 = 0; // 200*2*pi/60 = 20.94 rad/sec = 1200 deg/sec
float rpm_R0 = 0;
float control_rpm_L(float w_L0);
float control_rpm_R(float w_R0);

PID_controller w_L_controller;
PID_controller w_R_controller;
int rpm_controller_counter50Hz = 1;
// Controller variables ends -------------------------------------------------------------------------------

// Motor driving variables starts --------------------------------------------------------------------------
#define DIR_PIN_1 31
#define DIR_PIN_2 30
#define PWM_PIN_1 29
#define PWM_PIN_2 28
// Motor driving variables ends ----------------------------------------------------------------------------

// Xtras variables starts ----------------------------------------------------------------------------------
Math_functions math;
// Xtras variables ends ------------------------------------------------------------------------------------

// Function prototypes -------------------------------------------------------------------------------------
void wait();
void wheel_odometry_ddr(long N_L, long N_R, double L, double r, unsigned long N, double dt);
void init_motors();
void drive_motors(int16_t pwm_1=0, int16_t pwm_2=0);

struct States{
  float x = 0;
  float y = 0;
  float z = 0;
  float vx = 0;
  float vy = 0;
  float vz = 0;
  float ax = 0;
  float ay = 0;
  float az = 0;
  float phi = 0;
  float th = 0;
  float psi = 0;
  float wx = 0;
  float wy = 0;
  float wz = 0;
};

struct States_des{
  float x0 = 0;
  float y0 = 0;
  float z0 = 0;
  float vx0 = 0;
  float vy0 = 0;
  float vz0 = 0;
  float ax0 = 0;
  float ay0 = 0;
  float az0 = 0;
  float phi0 = 0;
  float th0 = 0;
  float psi0 = 0;
  float wx0 = 0;
  float wy0 = 0;
  float wz0 = 0;
};

struct States state;
struct States_des state_des;

float V_bat = 11.1;

// prepare data packet to transmit to esp32
union FloatToBytes{
  float val;
  char buff[4];
};

union BytesToFloat{
  char buff[4];
  float val;
};

union FloatToBytes f2b;
union BytesToFloat b2f;

char tx_packet[23]; // 0x91, x, y, yh, Vc, Wc, check_sum
char rx_packet[11]; // 0x92, Vc, Wc, check_sum
int rx_index = 0;
bool rx_packet_valid = false;
uint16_t check_sumn = 0;
uint8_t check_sum_1n = 0;
uint8_t check_sum_2n = 0;

int transmit_counter_25Hz = 1;


void setup(){
  // Initialize motors -------------------------------------------------------------------------------------
  init_motors();

  // Initialize encoders -----------------------------------------------------------------------------------
  enc_left.setInitConfig();
  enc_left.init();
  enc_right.setInitConfig();
  enc_right.init();

  // Initialize serial communication -----------------------------------------------------------------------
  Serial.begin(115200); // for usb comunication

  lpf_w_L.set_alpha_LPF(0.6825);
  lpf_w_R.set_alpha_LPF(0.6825);

  //w_L_controller
  w_L_controller.initialize();
  w_L_controller.set_gains(0.55,2.75,0);
  w_L_controller.set_I_max(200.0);
  w_L_controller.set_output_max(255.0);
  w_L_controller.set_lpf_alpha(0);

  //w_R_controller
  w_R_controller.initialize();
  w_R_controller.set_gains(0.55,2.75,0);
  w_R_controller.set_I_max(200.0);
  w_R_controller.set_output_max(255.0);
  w_R_controller.set_lpf_alpha(0);

  // communication with esp32
  Serial8.begin(115200);

  delay(5000);
  t = micros();
}

void loop(){
  // SECTION 1: GET DESIRED STATES -------------------------------------------------------------------------
  state_des.x0   = 0;
  state_des.y0   = 0;
  state_des.vx0  = 0;
  state_des.vy0  = 0;
  state_des.ax0  = 0;
  state_des.ay0  = 0;
  state_des.th0  = 0;
  state_des.psi0 = 0;
  state_des.wy0  = 0;
  state_des.wz0  = 0;

  // SECTION 3: READ BATTERY VOLTAGE -----------------------------------------------------------------------
  V_bat = 11.5;

  // SECTION 5: ESTIMATE POSITION --------------------------------------------------------------------------
  count_L = -enc_left.read();
  count_R = enc_right.read();
  wheel_odometry_ddr(count_L, count_R, L, r, N_encoder, dt);
  state.x   = x; //cm
  state.y   = y; //cm
  state.vx  = vx; //cm/sec
  state.vy  = vy; //cm/sec
  state.psi = yaw_angle;
  state.wz  = yaw_rate;
  Vc        = Vc;
  Wc        = Wc;
  w_L       = w_L;
  w_R       = w_R;

  //Serial.print(count_L); Serial.print('\t');
  //Serial.print(count_R); Serial.print('\t');
  //Serial.print(w_L*60.0/(2.0*PI)); Serial.print('\t');
  //Serial.print(w_R*60.0/(2.0*PI)); Serial.print('\t');
  //Serial.print(Vc); Serial.print('\t');
  //Serial.print(Wc*180.0/PI); Serial.print('\t');
  //Serial.print(state.x); Serial.print('\t');
  //Serial.print(state.y); Serial.print('\t');

  if(transmit_counter_25Hz==1){
    tx_packet[0] = 0x91; // message header

    f2b.val = state.x;
    tx_packet[1] = f2b.buff[0];
    tx_packet[2] = f2b.buff[1];
    tx_packet[3] = f2b.buff[2];
    tx_packet[4] = f2b.buff[3];

    f2b.val = state.y;
    tx_packet[5] = f2b.buff[0];
    tx_packet[6] = f2b.buff[1];
    tx_packet[7] = f2b.buff[2];
    tx_packet[8] = f2b.buff[3];

    f2b.val = state.psi;
    tx_packet[9] = f2b.buff[0];
    tx_packet[10] = f2b.buff[1];
    tx_packet[11] = f2b.buff[2];
    tx_packet[12] = f2b.buff[3];

    f2b.val = Vc;
    tx_packet[13] = f2b.buff[0];
    tx_packet[14] = f2b.buff[1];
    tx_packet[15] = f2b.buff[2];
    tx_packet[16] = f2b.buff[3];

    f2b.val = Wc;
    tx_packet[17] = f2b.buff[0];
    tx_packet[18] = f2b.buff[1];
    tx_packet[19] = f2b.buff[2];
    tx_packet[20] = f2b.buff[3];

    uint16_t check_sum = 0;
    for(int i=0;i<21;i++){
      check_sum += (uint16_t)tx_packet[i];
    }
    uint8_t check_sum_1 = (check_sum & 0xFF);
    uint8_t check_sum_2 = ((check_sum>>8) & 0xFF);
    tx_packet[21] = check_sum_1;
    tx_packet[22] = check_sum_2;

    for(int i=0;i<23;i++){
      Serial8.write(tx_packet[i]);
    }
  }
  transmit_counter_25Hz++;
  if(transmit_counter_25Hz>=21){
    transmit_counter_25Hz = 1;
  }

  // receiver Vc0, Wc0 from exp32
  while(Serial8.available()>0){
    char c = Serial8.read();
    if((c==0x92) || (rx_index>10)){
      rx_index = 0;
    }
    rx_packet[rx_index] = c;
    rx_index++;
    if(rx_index>10){
      rx_index = 0;
    }
    check_sumn = 0;
    for(int i=0;i<9;i++){
      check_sumn += (uint16_t)rx_packet[i];
    }
    check_sum_1n = (check_sumn & 0xFF);
    check_sum_2n = ((check_sumn>>8) & 0xFF);

    if((rx_packet[9]==check_sum_1n) && (rx_packet[10]==check_sum_2n)){
      rx_packet_valid = true;
    }
    else{
      rx_packet_valid = false;
    }
  }

  for(int i=0;i<11;i++){
    Serial.print(rx_packet[i],HEX); Serial.print(" ");
  }
  Serial.print(check_sum_1n,HEX); Serial.print(" ");
  Serial.print(check_sum_2n,HEX); Serial.print(" ");
  Serial.print(rx_packet_valid); Serial.print(" ");

  if(rx_packet_valid==true){
    b2f.buff[0] = rx_packet[1];
    b2f.buff[1] = rx_packet[2];
    b2f.buff[2] = rx_packet[3];
    b2f.buff[3] = rx_packet[4];
    Vc0 = b2f.val;

    b2f.buff[0] = rx_packet[5];
    b2f.buff[1] = rx_packet[6];
    b2f.buff[2] = rx_packet[7];
    b2f.buff[3] = rx_packet[8];
    Wc0 = b2f.val;
  }

  Serial.print(Vc0,7); Serial.print('\t');
  Serial.print(Wc0,7); Serial.print('\t');
  Serial.println();

  //Vc0 = 0.1; // m/sec
  //Wc0 = 0.1/0.6; //300.0*PI/180.0; // rad/sec
  if(VWc_controller_counter50Hz==1){
    /*Serial.print(Vc0*100); Serial.print('\t');
    Serial.print(Vc*100); Serial.print('\t');
    Serial.print(Wc0*180/PI); Serial.print('\t');
    Serial.print(Wc*180/PI); Serial.print('\t');*/

    validate_VWc0(Vc0,Wc0); // m/sec, rad/sec

    rpm_L0 = (2.0*Vc0 - Wc0*L)/(2.0*r); // output is in rad/sec
    rpm_R0 = (2.0*Vc0 + Wc0*L)/(2.0*r);

    rpm_L0 = rpm_L0*180.0/PI; // output is in deg/sec
    rpm_R0 = rpm_R0*180.0/PI;
  }
  VWc_controller_counter50Hz++;
  if(VWc_controller_counter50Hz==11){
    VWc_controller_counter50Hz = 1;
  }

  //rpm_L0 = 0; // 200*2*pi/60 = 20.94 rad/sec = 1200 deg/sec
  //rpm_R0 = 0;
  if(rpm_controller_counter50Hz==1){
    float PWM_L = control_rpm_L(rpm_L0); //input in deg/sec
    float PWM_R = control_rpm_R(rpm_R0);

    drive_motors(PWM_R,PWM_L); // right, left
    
    //Serial.print(rpm_L0); Serial.print('\t');
    //Serial.print(w_L*180.0/PI); Serial.print('\t');
    //Serial.print(rpm_R0); Serial.print('\t');
    //Serial.print(w_R*180.0/PI); Serial.print('\t');
  }
  rpm_controller_counter50Hz++;
  if(rpm_controller_counter50Hz==11){
    rpm_controller_counter50Hz = 1;
  }
  //Serial.print(1000000.0/(micros()-t)); Serial.print("\t");
  wait();
  //Serial.println();
}

void validate_VWc0(float Vc0_, float Wc0_){ // m/sec, rad/sec
  float Vc0_max = 1.0; // m/sec
  float Wc0_max = 8.2; // 470 deg/sec = 8.2 rad/sec

  bool feasibility = false;
  bool feas_1 = false;
  bool feas_2 = false;
  bool feas_3 = false;
  bool feas_4 = false;

  feas_1 = line_1(0,0)*line_1(Vc0_,Wc0_) >= 0;
  feas_2 = line_2(0,0)*line_2(Vc0_,Wc0_) >= 0;
  feas_3 = line_3(0,0)*line_3(Vc0_,Wc0_) >= 0;
  feas_4 = line_4(0,0)*line_4(Vc0_,Wc0_) >= 0;

  if((feas_1 && feas_2 && feas_3 && feas_4) == true){
    feasibility = true;
    Vc0 = Vc0_;
    Wc0 = Wc0_;
  }

  if(feasibility==false){
    // finding quadrant
    int quadrant = 1;
    if(Vc0_>=0){
      if(Wc0_>=0){
        quadrant = 1;
      }
      else{
        quadrant = 4;
      }
    }
    else{
      if(Wc0_>=0){
        quadrant = 2;
      }
      else{
        quadrant = 3;
      }
    }

    //int region = 0;
    if(quadrant==1){
      if(Wc0_>=Wc0_max){ //region = 7;
        Wc0 = Wc0_max;
        Vc0 = 0;
      }
      else{ //region = 3;
        Wc0 = Wc0_;
        Vc0 = (-Vc0_max*Wc0_ + Vc0_max*Wc0_max)/Wc0_max;
      }
    }
    else if(quadrant==2){
      if(Wc0_>=Wc0_max){ //region = 7;
        Wc0 = Wc0_max;
        Vc0 = 0;
      }
      else{ //region = 3;
        Wc0 = Wc0_;
        Vc0 = (Vc0_max*Wc0_ - Vc0_max*Wc0_max)/Wc0_max;
      }
    }
    else if(quadrant==3){
      if(Wc0_<=-Wc0_max){ //region = 7;
        Wc0 = -Wc0_max;
        Vc0 = 0;
      }
      else{ //region = 3;
        Wc0 = Wc0_;
        Vc0 = (-Vc0_max*Wc0_ - Vc0_max*Wc0_max)/Wc0_max;
      }
    }
    else{ // else if(quadrant==4)
      if(Wc0_<=-Wc0_max){ //region = 7;
        Wc0 = -Wc0_max;
        Vc0 = 0;
      }
      else{ //region = 3;
        Wc0 = Wc0_;
        Vc0 = (Vc0_max*Wc0_ + Vc0_max*Wc0_max)/Wc0_max;
      }
    }
  }
}

float line_1(float v,float w){
  return Wc0_max*v + Vc0_max*w - Vc0_max*Wc0_max;
}

float line_2(float v,float w){
  return Wc0_max*v - Vc0_max*w + Vc0_max*Wc0_max;
}

float line_3(float v,float w){
  return Wc0_max*v + Vc0_max*w + Vc0_max*Wc0_max;
}

float line_4(float v,float w){
  return Wc0_max*v - Vc0_max*w - Vc0_max*Wc0_max;
}

void wait(){
  while(micros()-t<loop_timer){}
  t = micros();
}

void wheel_odometry_ddr(long N_L, long N_R, double L, double r, unsigned long N, double dt){
  // calculate yaw angle
  double d_yaw_angle = ( (double)((N_R-N_R_pre)-(N_L-N_L_pre))*2.0*PI*r ) / (double(N)*L);
  yaw_angle += d_yaw_angle;
  yaw_angle = math.wrap(yaw_angle,-PI,PI);

  // calculate x,y position
  double d_L = ( (double)((N_L-N_L_pre)+(N_R-N_R_pre))*PI*r ) / (double(N));
  x += d_L*cos(yaw_angle);
  y += d_L*sin(yaw_angle);

  N_R_pre = N_R;
  N_L_pre = N_L;

  // wheel speed
  if(odom_counter_50Hz==1){
    w_L = (double)(count_L - count_L_pre) *2.0*PI / (((double)N)*dt*10.0);
    w_R = (double)(count_R - count_R_pre) *2.0*PI / (((double)N)*dt*10.0);
    count_L_pre = count_L;
    count_R_pre = count_R;

    //Serial.print(w_L*180.0/PI); Serial.print('\t');
    //Serial.print(w_R*180.0/PI); Serial.print('\t');
    w_L = lpf_w_L.apply_LPF(w_L);
    w_R = lpf_w_R.apply_LPF(w_R);
    //Serial.print(w_L*180.0/PI); Serial.print('\t');
    //Serial.print(w_R*180.0/PI); Serial.print('\t');

    Vc = (w_R+w_L)*r/2.0;
    Wc = (w_R-w_L)*r/L;
    //Serial.print(Vc*100.0); Serial.print('\t');
    //Serial.print(Wc*180.0/PI); Serial.print('\t');

    vx = Vc*cos(yaw_angle);
    vy = Vc*sin(yaw_angle);
    yaw_rate = Wc;
  }
  odom_counter_50Hz++;
  if(odom_counter_50Hz==11){
    odom_counter_50Hz = 1;
  }
}

void init_motors(){
  pinMode(DIR_PIN_1,OUTPUT);
  pinMode(DIR_PIN_2,OUTPUT);

  pinMode(PWM_PIN_1,OUTPUT);
  pinMode(PWM_PIN_2,OUTPUT);

  digitalWrite(DIR_PIN_1,LOW);
  digitalWrite(DIR_PIN_2,LOW);

  /*
  analogWriteResolution(12); // 0 to 4095, or 4096 for high
  analogWriteResolution(12);
  
  analogWriteFrequency(PWM_PIN_1,0);
  analogWriteFrequency(PWM_PIN_2,0);
  */
  
  analogWrite(PWM_PIN_1,0);
  analogWrite(PWM_PIN_2,0);
}

void drive_motors(int16_t pwm_1, int16_t pwm_2){
  if(pwm_1<0){
    digitalWrite(DIR_PIN_1,LOW);
    analogWrite(PWM_PIN_1,-pwm_1);
  }
  else{
    digitalWrite(DIR_PIN_1,HIGH);
    analogWrite(PWM_PIN_1,pwm_1);
  }

  if(pwm_2<0){
    digitalWrite(DIR_PIN_2,LOW);
    analogWrite(PWM_PIN_2,-pwm_2);
  }
  else{
    digitalWrite(DIR_PIN_2,HIGH);
    analogWrite(PWM_PIN_2,pwm_2);
  }
}

float control_rpm_L(float w_L0){
  float pwm = w_L_controller.calculate_output2(w_L0,w_L*180.0/PI,dt*10.0);
  return pwm;
}

float control_rpm_R(float w_R0){
  float pwm = w_R_controller.calculate_output2(w_R0,w_R*180.0/PI,dt*10.0);
  return pwm;
}
